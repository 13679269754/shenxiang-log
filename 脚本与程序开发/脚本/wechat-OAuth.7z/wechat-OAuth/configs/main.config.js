module.exports = {
    // 企业信息
    corp_id: "wwceb888aab4491588",

    // 应用信息
    agent_id: "1000004",
    app_secret:"-kaDO7bryMhCxUVXeu7gKqdxHgHxWcMBxGKQD_F_Vbw",

    // 网站根目录 URL
    site_base:'http://myapp.com:3000',

    // 企业主页 URL
    home_path:'/home',

    // 授权后跳转 URL
    app_path:'/app',

    // 通讯录管理 secret
    contact_secret :'',

    // 机器人 WebHook
    robot_webhook:"https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=6549a7c1-8e97-44ba-a481-11f02bea524e"

}
