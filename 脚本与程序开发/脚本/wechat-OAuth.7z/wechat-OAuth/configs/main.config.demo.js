module.exports = {
    // 企业信息
    corp_id: "",
    
    // 应用信息
    agent_id: "",
    app_secret:"",

    // 网站根目录 URL
    site_base:'http://myapp.com:3000',

    // 企业主页 URL
    home_path:'/home',

    // 授权后跳转 URL
    app_path:'/app',

    // 通讯录管理 secret
    contact_secret :'',

    // 机器人 WebHook
    robot_webhook:''
   
}
