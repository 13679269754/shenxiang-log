import os,shutil,sys
import logging as lg
import datetime
import subprocess
from mysql_auto_restore_config import restore_base_dir,log_dir,change_port
from mysql_auto_restore_util import SendMessage


already_restore_keep_wait_day = 3
current_time = datetime.datetime.now() 
current_min = current_time.strftime("%Y-%m-%d_%H%M")
current_day = current_time.strftime("%Y%m%d")
log_file = os.path.join(log_dir,f'mysql_auto_restore_delete.log')




def get_ip_address():

    # 执行ifconfig命令并获取输出
    output = subprocess.check_output(['/usr/sbin/ifconfig']).decode()

    # 在输出中查找非回环IP地址
    ip_address = None
    for line in output.split('\n'):
        if 'inet ' in line and '127.0.0.1' not in line:
            ip_address = line.split('inet ')[1].split(' ')[0]
            break
    return ip_address


logging = ''
def set_logger():
    global logging
    # 定义日志格式
    formatter = lg.Formatter('%(asctime)s - %(filename)s - %(levelname)s: %(message)s',datefmt='%Y-%m-%d %H:%M:%S')

    # 创建Logger对象
    logging = lg.getLogger()
    logging.setLevel(lg.DEBUG)

    # 创建文件处理器
    file_handler = lg.FileHandler(log_file)
    file_handler.setLevel(lg.INFO)

    # 创建终端处理器
    console_handler = lg.StreamHandler()
    console_handler.setLevel(lg.INFO)

    # 设置处理器的格式
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)

    # 将处理器添加到Logger对象
    logging.addHandler(file_handler)
    logging.addHandler(console_handler)


def get_mysql_info():
    check_port = change_port
    current_mysql_cmd = f"""/usr/bin/ps -ef | /usr/bin/grep mysql | /usr/bin/grep -w mysqld | /usr/bin/grep {check_port} | /usr/bin/grep -v grep"""
    current_mysql_dir = ''
    try:
        output = subprocess.check_output(current_mysql_cmd, shell=True).decode().strip()
        data = ''
        for i in output.split():
            if '--' in i and 'socket' in i:
                data = i.split('=')[1]
                break
        if data:
            current_mysql_dir = data.replace(restore_base_dir,'').split('/')[1]
            
        else:
            logging.warning(f'未获取到当前运行的 Mysql {check_port}, 退出脚本')
            sys.exit(1)
    except Exception as e:
        logging.warning(f'未获取到当前运行的 Mysql {check_port}, 退出脚本')
        logging.error(e)
        sys.exit(1)
    
    current_mysql_start_time = current_mysql_dir.split('_')[0] + ' ' + current_mysql_dir.split('_')[1]
    current_mysql_oldbackup_time = current_mysql_dir.split('_')[2]
    logging.info(f'获取到当前运行的 Mysql {check_port} 目录名称: {current_mysql_dir}')
    logging.info(f'获取到当前运行的 Mysql {check_port} 恢复时间: {current_mysql_start_time}')
    logging.info(f'获取到当前运行的 Mysql {check_port} 备份时间: {current_mysql_oldbackup_time}')
    return current_mysql_start_time,current_mysql_oldbackup_time


def check_ifdelete(start_time):
    if isinstance(start_time,str):
        start_time = datetime.datetime.strptime(start_time, "%Y-%m-%d %H%M")
    day_info =  (start_time + datetime.timedelta(days = already_restore_keep_wait_day)).strftime("%Y%m%d")


    logging.info(f'当前时间为：{current_day} ')
    if int(day_info) <= int(current_day):
        logging.info(f'需要删除 {start_time.strftime("%Y-%m-%d")} 前的备份数据库')
        return True
    else:
        logging.info(f'不需要删除 {start_time.strftime("%Y-%m-%d")} 前的备份数据库')
        return False



def delete_backup_dir(need_dir,target_backup_dir):
    """删除备份目录"""
    data = datetime.datetime.strptime(need_dir, "%Y-%m-%d %H%M").strftime("%Y%m%d%H%M")
    need_dir_int = int(data)
    dir_list = os.listdir(target_backup_dir)
    str = ''
    for dir in dir_list:
        dir_date = datetime.datetime.strptime(dir.split('_')[0], "%Y-%m-%d").strftime("%Y%m%d")
        dir_time = dir.split('_')[1]
        dir_int = int(dir_date + dir_time)
        if dir_int < need_dir_int:
            delete_dir = os.path.join(target_backup_dir,dir)
            logging.info(f'开始删除 {delete_dir} .....')
            shutil.rmtree(delete_dir)
            str = str + ',' + delete_dir


def run():
    set_logger()
    logging.info("=" * 180)
    ipaddress = get_ip_address()
    current_mysql_start_time,_ = get_mysql_info()
    if check_ifdelete(current_mysql_start_time):
        delete_backup_dir(current_mysql_start_time,restore_base_dir)
    

if __name__ =="__main__":
    run()
