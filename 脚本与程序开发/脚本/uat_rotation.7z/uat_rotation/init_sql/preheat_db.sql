SELECT COUNT(*) FROM user_data.`uses_account`;
SELECT COUNT(*) FROM user_data.`uses_user_info`;
