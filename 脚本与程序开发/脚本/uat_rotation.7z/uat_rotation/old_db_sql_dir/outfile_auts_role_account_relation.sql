SELECT * FROM `auth`.`auts_role_account_relation` WHERE create_time>=DATE_ADD(NOW(),INTERVAL -10 DAY) INTO OUTFILE "auts_role_account_relation.sql" FIELDS TERMINATED BY ','; 
