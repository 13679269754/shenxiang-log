#!/usr/local/bin/python3
import requests, sys, json, time
import urllib3
from mysql_auto_restore_config import webhook_url, Corpid,  Secret, agent_id, token_file, auto_send_reboot_msg,auto_send_msg, csv_file ,dba_column_need,other_column_need,mail_info,rows_limit
import os,sys
import re
import openpyxl
import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from email.header import Header
import smtplib
import pandas as pd
import warnings
warnings.filterwarnings('ignore')


requests.packages.urllib3.disable_warnings()
urllib3.disable_warnings()

class send_mail:
    def __init__(self):
        self.date = time.strftime("%Y%m%d", time.localtime())
        self.week = time.strftime("%w", time.localtime())
        self.day = time.strftime("%d", time.localtime())
        self.yday = (datetime.datetime.now()).strftime('%Y%m%d')
        self.start_time = datetime.datetime.now()

    def table_info(self, data_df, title, message_head):
        table_title = """<p><strong>%s</strong></p>\n""" % (title.strip())
        table_style = """border="1" style="font-family:'Courier New'; border-collapse: collapse; " align = "left" valign="left" Cellpadding = "3" bordercolor="black" """

        data_count = len(data_df.index)
        if data_count == 0:
            msg_html_info = """<p><strong>%s</strong></p>\n""" % ('无数据')
            message_html_info = """%s\n%s\n""" % (str(table_title), str(msg_html_info))
        else:
            table_header_info = ''
            msg_html_info = ''
            for message_head_dat in message_head:
                info = message_head_dat
                if info != '':
                    table_header_info = """%s<th>%s</th>\n""" % (str(table_header_info), str(info))
            table_header = """<tr bgcolor="#C0C0C0">\n%s</tr>\n""" % (str(table_header_info))

            for message in data_df.iterrows():
                msg_info = ''
                for msg in message[1]:
                    if msg or msg == 0:
                        if re.search(r'^\.\d+$|^\.\d+\%$', str(msg)):
                            msg = '0.%s' % (str(msg))
                        msg_info = """%s<td>%s</td>\n""" % (str(msg_info), str(msg))
                msg_html_info = """%s<tr>%s</tr>\n""" % (str(msg_html_info), str(msg_info))

            message_html_info = """%s<table %s>\n%s%s</font>\n</table>\n""" % (
            str(table_title), str(table_style), str(table_header), str(msg_html_info))
        return message_html_info

    def read_csv(self,column_flag):
        df = pd.read_csv(csv_file,encoding='utf-8')
        return_info = df[df['run_type_num'] == 1].sort_values(by='log_date',ascending=False)[0:rows_limit]
        if column_flag:
            column_list = dba_column_need
        else:
            column_list = other_column_need
        return return_info[column_list]

    def send_mail(self,mail_info):
        with open('mysql_sendmail.dat', 'w+') as f:
            for line in mail_info:
                mail_name = line['mail_name']
                mail_flag = line['mail_flag']
                mail_user = line['mail_user']
                mail_cc = line['mail_cc']
                column_flag = line['column_flag']

                # 设定邮件时间格式
                if re.search(r'_日期$',str(mail_name)):
                    sub = u'%s'%(re.sub(r'_日期$',str(f'_{self.yday}'),str(mail_name)))
                    mail_name = sub
                else:
                    sub = u'%s'%(str(mail_name))

                msg = f'数据 {mail_name} 查询完成，请查收.\n'
                data_df = self.read_csv(column_flag)
                message_head = []

                for line in data_df.columns:
                    message_head.append(line)

                if mail_flag == 1 or mail_flag == 2:
                    message_html_info = self.table_info(data_df,sub,message_head)
                    msg = '%s<br clear = "all">\n%s\n' % (msg, message_html_info)



                msg = """<html>
                                 <head>
                                    <style type=\"text/css\"> body {font:13pt Arial,Helvetica,sans-serif; color:black; background:White;}
                                    p{font:12pt Arial,Helvetica,sans-serif; color:black; background:White;} 
                                    table,tr,td {font:11pt Arial,Helvetica,sans-serif;white-space: nowrap; color:Black; background:#FCF8F8;} 
                                    th {font:bold 10pt Arial,Helvetica,sans-serif; color:black; background:#D8D8D8;}  
                                    </style>
                                 </head>
                                  <body>
                                        %s
                                  </body>
                                 </html>
                    """ % (msg)

                mime = MIMEMultipart()
                mime.attach(MIMEText(msg, 'html', 'utf-8'))

                # if excel_flag > 0:
                #     # 构造附件
                #     att = MIMEApplication(open(excel_path, 'rb').read())
                #     att.add_header('Content-Disposition', 'attachment', filename= Header('%s.xlsx'%(sub), 'utf-8').encode())
                #     mime.attach(att)

                mime['To'] = mail_user
                mime['Cc'] = mail_cc
                mime['Subject'] = mail_name
                mime['From'] = 'DBA@dazhuanjia.com'
                mail_user = mail_user.split(',')

                if mail_cc:
                    mail_user.extend(mail_cc.split(','))
                send = smtplib.SMTP("localhost")
                send.sendmail('localhost',mail_user, mime.as_string())




def GetToken(Corpid, Secret):
    """获取access_token"""
    Url = "https://qyapi.weixin.qq.com/cgi-bin/gettoken"
    Data = {
        "corpid": Corpid,
        "corpsecret": Secret
    }
    r = requests.get(url=Url, params=Data, verify=False).json()
    c_time = int(time.time())
    if r.get('errcode') != 0:
        return False
    else:
        try:
            with open(token_file, 'r') as f:
                tokenlist = f.readlines()
                if len(tokenlist) == 2 and c_time < int(tokenlist[1].strip()):
                    token = tokenlist[0].strip()
                    expires = tokenlist[1].strip()
                else:
                    raise Exception
        except Exception:
            with open(token_file, 'w') as f:
                try:
                    token = r.get('access_token')
                    expires = int(r.get('expires_in', 0)) + c_time
                    f.write('%s\n%s' % (token, expires))
                except Exception as e:
                    token = ''
        return token


def SendMessage(Subject, Content, Agentid):
    if auto_send_reboot_msg:
        Url = webhook_url
        Data = {
            "msgtype": "text",
            "text": {"content": Subject + '\n' + Content},
        }
        r = requests.post(url=Url, data=json.dumps(Data), verify=False)
        print(r.json()['errcode'])
        return r.json()['errcode']


    if auto_send_msg:
        """发送消息"""
        # 获取token信息
        Token = GetToken(Corpid, Secret)
        # 发送消息
        Url = "https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token=%s" % Token
        Data = {
            "msgtype": "text",
            "agentid": Agentid,
            "text": {"content": Subject + '\n' + Content},
            "touser":'@all',
            "safe": "0"
        }

        r = requests.post(url=Url, data=json.dumps(Data), verify=False)
        # 如果发送失败，将重试三次
        n = 1
        while r.json()['errcode'] != 0 and n < 4:
            n = n + 1
            Token = GetToken(Corpid, Secret)
            if Token:
                Url = "https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token=%s" % Token
                r = requests.post(url=Url, data=json.dumps(Data), verify=False)
        return r.json()




if __name__ == '__main__':
    # # 消息标题
    # subject = sys.argv[2]
    # # 消息内容
    # msg = sys.argv[3]
    # for agentid in agent_id:
    #     Status = SendMessage(subject, msg, agentid)

    a = send_mail()
    a.send_mail(mail_info)
