"""
######################################################################
##  Mysql 数据库自动还原脚本
##  前提条件：
##      1. 安装 Python 环境
##      2. 安装 Mysql 软件
##      3. 安全 qpress 软件
##         pip3 install paramiko
##         pip3 install colorlog
##
######################################################################
"""

import re,os,time,pwd,shutil
import argparse
import sys
import logging as lg
import functools
import paramiko
import stat
import datetime
import random
import calendar
import pymysql
import traceback
import socket
from mysql_auto_restore_config import *
from mysql_auto_restore_util import SendMessage,send_mail
import pandas as pd


current_min = datetime.datetime.now().strftime("%Y-%m-%d_%H%M")
current_day = datetime.datetime.now().strftime("%Y%m%d")
log_file = os.path.join(log_dir,f'mysql_auto_restore_{current_day}.log')


def get_ip_address():
    import subprocess

    # 执行ifconfig命令并获取输出
    output = subprocess.check_output(['/usr/sbin/ifconfig']).decode()

    # 在输出中查找非回环IP地址
    ip_address = None
    for line in output.split('\n'):
        if 'inet ' in line and '127.0.0.1' not in line:
            ip_address = line.split('inet ')[1].split(' ')[0]
            break

    return ip_address

ipaddress = get_ip_address()
subject = f'{ipaddress} UAT 自动恢复脚本 \n ----------------------------------------------------------'


run_type = -1
loop_type = -1
excute_day = ''
restore_date = ''
mysql_dir = ''
already_switch = ''

restore_info = {
    'log_file':log_file,
    'source_backup_host':source_backup_host,
    'state':'beginning'
}

def parse_arg():
    """
    解析命令行参数
    :return:
    """
    global run_type
    global loop_type
    global excute_day
    global restore_date
    global mysql_dir
    global already_switch

    # 创建ArgumentParser对象
    parser = argparse.ArgumentParser(description='自动恢复脚本',
                                     epilog="以上便是如何使用 自动恢复脚本",
                                     formatter_class=argparse.RawTextHelpFormatter,)

    # 添加互斥组
    group = parser.add_mutually_exclusive_group()
    # 给互斥组添加两个参数
    # 给参数的action属性赋值store_true，程序默认为false,当你执行这个命令的时候，默认值被激活成True
    run_type_dict = {
        1: '执行备份恢复并切换环境',
        2: '手动删除过期备份',
        3: '手动启动未切换数据库',
        4: '手动切换备份数据库',
        5: '手动初始化数据库数据'
    }

    loop_type_dict = {
        1: '每月恢复1号前一天数据 excute_day 指定执行时间(每月第几天)  ',
        2: '每周恢复上周日数据   excute_day 指定执行时间(每周第几天) ',
        3: f'每月恢复前 {timedelta_day} 天数据   excute_day 为0 代表每天都执行 大于0 代表每月几号执行',
        4: f'每周恢复前 {timedelta_day} 天数据   excute_day 为0 代表每天都执行 大于0 代表每周周几执行',
        11: '模糊指定备份',
        12 : '精准指定备份'
    }


    group.add_argument('-r', '--restore', action='store_true', help=f'{run_type_dict[1]}')
    group.add_argument('-d', '--delete', action='store_true', help=f'{run_type_dict[2]}')
    group.add_argument('-i', '--init', action='store_true', help=f'{run_type_dict[3]}')
    group.add_argument('-s', '--switch', action='store_true', help=f'{run_type_dict[4]}')
    group.add_argument('-e', '--execute_sql', action='store_true', help=f'{run_type_dict[5]}')

    # 添加命令行参数
    parser.add_argument("-l",
                        "--loop_type",
                        type=int,
                        metavar='int',
                        help=f"""执行周期：\n1  {loop_type_dict[1]}  \n2  {loop_type_dict[2]}  \n3  {loop_type_dict[3]}  \n4  {loop_type_dict[4]}  \n11 {loop_type_dict[11]}  \n12 {loop_type_dict[12]}"""
                        )

    parser.add_argument("-c","--excute_day", type=str, metavar='str',help="""指定执行时间（多次指定以逗号分割）""")
    parser.add_argument("-t","--restore_date", type=str, metavar='str',help="""需要恢复或删除的备份日期(格式：20230101 或者 备份目录全名)""")
    parser.add_argument("-m","--mysql_dir", type=str, metavar='str', help="""启动备份 Mysql 时的 Mysql Base 目录（conf目录上一级）""")
    parser.add_argument("-a", "--already_switch", type=bool, metavar='bool', help="""是否已经完成切换""")
    parser.add_argument("-v","--version", action='version',version='%(prog)s 2.0')


    # 解析命令行参数
    args = parser.parse_args()



    # 根据参数值判断其他参数必要性
    if args.switch:
        run_type = 4
    elif args.init:
        run_type = 3
        if not args.mysql_dir:
            parser.error('指定 --init 时，-m|--mysql_dir 参数是必需的')
        else:
            mysql_dir = args.mysql_dir
    elif args.execute_sql:
        run_type = 5
        if not args.mysql_dir:
            parser.error('指定 --execute_sql 时，-m|--mysql_dir 参数是必需的')
        else:
            mysql_dir = args.mysql_dir
        already_switch = args.already_switch
    elif args.delete:
        run_type = 2
        if not args.restore_date:
            parser.error('指定 --delete 时，-t|--restore_date 参数是必需的')
        else:
            restore_date = args.restore_date


    elif args.restore:
        run_type = 1
        if not args.loop_type:
            parser.error('指定 --restore 时，-l|--loop_type 参数是必需的')
        else:
            loop_type = args.loop_type
            if loop_type not in [1,2,3,4,11,12]:
                parser.error('请查看 -l|--loop_type 帮助文档')


        if loop_type in [11,12]:
            if not args.restore_date:
                parser.error('指定 --restore 时，-t|--restore_date 参数是必需的')
            else:
                restore_date = args.restore_date
        else:
            if not args.excute_day:
                parser.error('指定 --restore 时，-c|--excute_day 参数是必需的')
            else:
                excute_day = args.excute_day

    if not args.switch and not args.delete and not args.init and not args.restore and not args.execute_sql:
        parser.error('指定 --switch|--delete|--init|--restore|--execute_sql 参数是必需的')


    arg_dict = {
        'run_type': '无数据' if run_type == -1 else run_type_dict[run_type],
        'loop_type': '无数据' if loop_type == -1 else loop_type_dict[loop_type],
        'excute_day': '无数据' if not excute_day else str(excute_day),
        'restore_date': '无数据' if not restore_date else str(restore_date),
        'mysql_dir':'无数据' if not mysql_dir else str(mysql_dir),
        'already_switch':'无数据' if not already_switch else str(already_switch)
    }

    for k,v in arg_dict.items():
        print(k.ljust(20) + ': ' + v)
    restore_info.update(arg_dict)
    restore_info['run_type_num'] = run_type


logging = ''
# 定义自定义日志级别的数值
SUCCESS_LEVEL = 25

# 定义自定义日志级别的日志方法
def success(self, message, *args, **kwargs):
    if self.isEnabledFor(SUCCESS_LEVEL):
        self._log(SUCCESS_LEVEL, message, args, **kwargs)

def set_logger(log_dir):
    global logging
    # 定义自定义日志级别的名称
    lg.addLevelName(SUCCESS_LEVEL, "SUCCESS")

    # 定义日志格式
    try:
        import colorlog
        # 创建彩色日志格式
        formatter = colorlog.ColoredFormatter(
            '%(log_color)s%(asctime)s - %(filename)s[line:%(lineno)d] - %(levelname)s: %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S',
            log_colors={
                'DEBUG': 'cyan',
                'INFO': 'white',
                'WARNING': 'yellow',
                'ERROR': 'red',
                'CRITICAL': 'red,bg_white',
                'SUCCESS':'green'
            }
        )
    except:
        formatter = lg.Formatter('%(asctime)s - %(filename)s[line:%(lineno)d] - %(levelname)s: %(message)s',datefmt='%Y-%m-%d %H:%M:%S')

    # 创建Logger对象
    logging = lg.getLogger()

    # 将自定义日志级别方法添加到logger对象
    lg.Logger.success = success
    logging.setLevel(lg.DEBUG)

    # 创建文件处理器
    file_handler = lg.FileHandler(log_file)
    file_handler.setLevel(lg.DEBUG)

    # 创建终端处理器
    console_handler = lg.StreamHandler()
    console_handler.setLevel(log_level)

    run_handler = lg.FileHandler(os.path.join(log_dir,'mysql_auto_restore_run.log'))
    run_handler.setLevel(lg.INFO)

    # 设置处理器的格式
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)
    run_handler.setFormatter(formatter)

    # 将处理器添加到Logger对象
    logging.addHandler(file_handler)
    logging.addHandler(console_handler)
    logging.addHandler(run_handler)

def change_second(seconds):
    return_info = 0
    if seconds > 300 and seconds <= 3600:
        return_info = f'{round(seconds / 60,2)} min'
    elif seconds > 3600:
        return_info = f'{round(seconds / 60 / 60,2)} h'
    else:
        return_info = f'{round(seconds,3)} s'
    return return_info

func_exec_time_dic={}
def log_decorator(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        func_start = datetime.datetime.now()
        logging.info("=" * 120)
        logging.success(f"Calling function {func.__name__}")
        logging.info(f"{func.__doc__}".strip())

        try:
            restore_info['state'] = f'{func.__name__} beginning'
            result = func(*args, **kwargs)
        except Exception as e:
            logging.error(f"Function {func.__name__} executed failed")
            logging.error(f"{e}")
            if print_error_line:
                traceback.print_exc()

            # 消息内容
            msg = f"Function {func.__name__} executed failed \n请查看恢复日志：{log_dir}"
            for agentid in agent_id:
                Status = SendMessage(subject, msg, agentid)
            restore_info['state'] = f'{func.__name__} failed'
            sys.exit(0)
        logging.success(f"Function {func.__name__} executed successfully")
        restore_info['state'] = f'{func.__name__} successed'
        func_end = datetime.datetime.now()
        func_exec_time_second = (func_end - func_start).total_seconds()
        func_exec_time_dic[func.__name__]=func_exec_time_second
        logging.success(f"Function {func.__name__} executed time: {change_second(func_exec_time_second)}")
        logging.info("="*120)
        return result
    return wrapper

@log_decorator
def create_restore_dir(restore_dir,restore_date):
    """
    创建恢复目录
    """
    restore_db_dir = os.path.join(restore_dir, f"{current_min}_{datetime.datetime.strptime(restore_date,'%Y%m%d').strftime('%Y-%m-%d')}",'dbmysql')
    restore_db_dir_dict={
        'restore_db_dir' : restore_db_dir,
        'restore_db_log_dir': os.path.join(restore_db_dir,'log'),
        'restore_db_conf_dir': os.path.join(restore_db_dir,'conf'),
        'restore_db_tmp_dir': os.path.join(restore_db_dir,'tmp'),
        'restore_db_run_dir': os.path.join(restore_db_dir,'run'),
        'restore_db_data_dir': os.path.join(restore_db_dir,'data'),
    }

    if not os.path.exists(restore_db_dir):
        os.makedirs(restore_db_dir_dict['restore_db_dir'])
        os.makedirs(restore_db_dir_dict['restore_db_log_dir'])
        os.makedirs(restore_db_dir_dict['restore_db_conf_dir'])
        os.makedirs(restore_db_dir_dict['restore_db_tmp_dir'])
        os.makedirs(restore_db_dir_dict['restore_db_run_dir'])
        os.makedirs(restore_db_dir_dict['restore_db_data_dir'])
        logging.info(f'创建恢复目录 {restore_db_dir} 成功')

    else:
        raise Exception(f'创建恢复目录 {restore_db_dir} 失败，请检查目录是否已经存在')

    return restore_db_dir_dict


def get_restore_date():
    "获取需要恢复的备份日期 type : 1 每月恢复1号前一天 excute_day指定执行时间  2 每周恢复 excute_day指定执行时间 3 每天恢复前一天 excute_day 为0 代表每天都执行 大于0 代表每月几号执行 4 每天恢复前一天 excute_day 为0 代表每天都执行 大于0 代表每月周几执行  11 模糊指定备份 12 精准指定备份"
    if loop_type in (11,12):
        return restore_date

    # 获取当前日期和时间
    now = datetime.datetime.now()
    # 获取当前日期的年份和月份
    year = now.year
    month = now.month
    day = now.day
    weekday = now.weekday() + 1

    # 获取该月的最后一天
    last_day = calendar.monthrange(year, month)[1]
    excute_day_list = [min(int(i), last_day) for i in excute_day.split(',')]


    if loop_type == 1:
        # 获取当前时间的每个月的1号
        first_of_month = now.replace(day=1) - datetime.timedelta(days=1)
        if day in excute_day_list:
            return first_of_month.strftime('%Y%m%d')
        else:
            return False

    if loop_type == 2:
        # 获取当前时间的每周的星期天
        sunday = now - datetime.timedelta(days=now.weekday()) - datetime.timedelta(days=1)
        if day in excute_day_list:
            return sunday.strftime('%Y%m%d')
        else:
            return False

    if loop_type == 3:
        if 0 in excute_day_list:
            return_day = now - datetime.timedelta(days=timedelta_day)
            return return_day.strftime('%Y%m%d')
        else:
            if day in excute_day_list:
                return_day = now - datetime.timedelta(days=timedelta_day)
                return return_day.strftime('%Y%m%d')
            else:
                return False

    if loop_type == 4:
        excute_day_list = [min(int(i), 7) for i in excute_day.split(',')]
        if 0 in excute_day_list:
            return_day = now - datetime.timedelta(days=timedelta_day)
            return return_day.strftime('%Y%m%d')
        else:
            if weekday in excute_day_list:
                return_day = now - datetime.timedelta(days=timedelta_day)
                return return_day.strftime('%Y%m%d')
            else:
                return False


def get_all_files_in_remote_dir(sftp, remote_dir):
    """
    获取远端linux主机上指定目录及其子目录下的所有文件
    """
    # 保存所有文件的列表
    all_files = list()

    # 去掉路径字符串最后的字符'/'，如果有的话
    if remote_dir[-1] == '/':
        remote_dir = remote_dir[0:-1]
        print(remote_dir)

    # 获取当前指定目录下的所有目录及文件，包含属性值
    files = sftp.listdir_attr(remote_dir)
    for x in files:
        # remote_dir目录中每一个文件或目录的完整路径
        filename = remote_dir + '/' + x.filename
        # 如果是目录，则递归处理该目录，这里用到了stat库中的S_ISDIR方法，与linux中的宏的名字完全一致
        if stat.S_ISDIR(x.st_mode):
            all_files.extend(get_all_files_in_remote_dir(sftp, filename))
        else:
            all_files.append(filename)
    return all_files

@log_decorator
def sync_backup_file(source_dir,source_user,source_host,source_passwd,target_dir,restore_date):
    """
    传递备份文件
    """
    # 创建ssh访问
    try:
        ssh = paramiko.SSHClient()
        ssh.load_system_host_keys()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())  # 允许连接不在know_hosts文件中的主机
        ssh.connect(source_host, port=22, username=source_user, password=source_passwd)  # 远程访问的服务器信息

        filedir_name_cmd = f"ls -afl {source_dir}| grep {restore_date} | sort | tail -n 1 |awk ' {{print $9}}'"
        stdin, stdout, stderr = ssh.exec_command(filedir_name_cmd)
        if stderr.read().decode('utf-8').strip():
            ssh.close()
            raise Exception(f"源备份文件查询失败，请检查相关语句：{filedir_name_cmd}\n{stderr.read().decode('utf-8').strip()}")
        else:
            source_file_name = stdout.read().decode('utf-8').strip()

        if source_file_name:

            logging.success(f"源备份文件查询为 {source_file_name}")
            source_file_dir = os.path.join(source_dir, source_file_name)
            target_file_dir = os.path.join(target_dir, source_file_name)

            check_cmd = f"ls {source_file_dir} | grep -i Successed.txt | wc -l"
            stdin, stdout, stderr = ssh.exec_command(check_cmd)
           
            if stdout.read().decode('utf-8').strip() != '1':
                ssh.close()
                raise Exception(f"源备份文件检查失败，请检查相关语句：{check_cmd}\nSuccessed 文件数{stdout.read().decode('utf-8').strip()}")


            restore_info['source_file_dir'] = source_file_name


            if target_file_dir[-1] == '/':
                target_file_dir = target_file_dir[0:-1]

            if not os.path.exists(target_file_dir):
                os.makedirs(target_file_dir)


            if not os.path.exists(os.path.join(target_file_dir,'Sync_Successed.txt')):

                logging.success(f"需要传输的源备份目录：{source_file_dir}")
                logging.success(f"需要传输的目标备份目录：{target_file_dir}")
                try:
                    # 创建scp,下载文件
                    sftp = paramiko.SFTPClient.from_transport(ssh.get_transport(),window_size=50*1024*1024*1024)


                    all_files = get_all_files_in_remote_dir(sftp, source_file_dir)

                    # 依次get每一个文件
                    for x in all_files:
                        filename = x.replace(source_file_dir,'')
                        target_filename = target_file_dir + filename

                        dir = os.path.dirname(target_filename)
                        if not os.path.exists(dir):
                            os.makedirs(dir, exist_ok=False)
                        logging.debug(f'Get文件 {x} 传输至 {target_filename} ...')
                        sftp.get(x, target_filename)

                    with open(os.path.join(target_file_dir,'Sync_Successed.txt'),'w') as f:
                        f.write('sync successed')
                except Exception as e:
                    raise e
                finally:
                    sftp.close()
                    ssh.close()
            else:
                logging.warning(f"源备份目录：{source_file_dir} 已经传输成功，不需要重新传输")

            ssh.close()
            restore_info['start_size'] = get_folder_size(target_file_dir)

            dir_info = datetime.datetime.strptime(target_file_dir.split('/')[-1], '%Y%m%d_%H_%M_%S')
            target_file = ''
            for dir_name in os.listdir(target_file_dir):
                dir_path = os.path.join(target_file_dir, dir_name)
                if os.path.isdir(dir_path):
                    if re.match(f"""^{dir_info.strftime('%Y')}.*{dir_info.strftime('%m')}.*{dir_info.strftime('%d')}.*{dir_info.strftime('%H')}.*{dir_info.strftime('%M')}.*{dir_info.strftime('%S')}$""", dir_name):
                        target_file = dir_path
                        break

            if target_file:
                restore_info['target_file_dir'] = target_file
                return os.path.join(target_file_dir, target_file)
            else:
                raise Exception('Sync 未查询到源备份文件....')
        else:
            logging.warning("未查询到源备份文件....")
            ssh.close()
            sys.exit(0)
    except Exception as e:
        raise e
    finally:
        ssh.close()


def get_folder_size(folder_path):
    total_size = 0
    for path, dirs, files in os.walk(folder_path):
        for file in files:
            file_path = os.path.join(path, file)
            total_size += os.path.getsize(file_path)
    if total_size / 1024 / 1024 / 1024 > 0:
        return_info =  f'{round(total_size / 1024 / 1024 / 1024,2)} G'
    else:
        return_info = f'{round(total_size / 1024 / 1024,2)} M'
    return return_info

@log_decorator
def restore_decompress_db(target_backup_dir):
    """解压备份文件"""
    decompress_log_file = os.path.join(target_backup_dir, 'backup_decompress.log')
    ## 2025-03-24添加--remove-original 
    uncompress_cmd = f"xtrabackup --decompress --parallel={paraller} --target-dir={target_backup_dir}  2> {decompress_log_file}"

    if os.path.exists(decompress_log_file):
        with open(decompress_log_file, 'r') as f:
            lines =  f.readlines()
            if lines:
                last_line = lines[-1].strip()
            else:
                last_line = 'Failed'

        if re.search('completed OK',last_line):
            logging.warning("decompress 已经执行成功，无需再次执行")
            execute_code = 0
        else:
            execute_code = 1
    else:
        execute_code = 1

    end_size = '已执行'
    if execute_code == 1:
        logging.info(f"开始执行 decompress 脚本：{uncompress_cmd}")
        exit_code  = os.system(uncompress_cmd)

        with open(decompress_log_file, 'r') as f:
            lines =  f.readlines()
            if lines:
                last_line = lines[-1].strip()
            else:
                last_line = 'Failed'

        if exit_code > 0 or not re.search('completed OK', last_line):
            raise Exception(f"执行 decompress 脚本错误：{uncompress_cmd}")
        logging.info(f"执行 decompress 脚本完成")
        end_size = get_folder_size(target_backup_dir)

    restore_info['decompress_size'] = end_size

@log_decorator
def restore_prepare_db(target_backup_dir):
    """恢复数据库前，先进行预处理"""

    prepare_log_file = os.path.join(target_backup_dir, 'backup_prepare.log')
    prepare_cmd = f"xtrabackup --prepare --target-dir={target_backup_dir} 2> {prepare_log_file}"

    if os.path.exists(prepare_log_file):
        with open(prepare_log_file, 'r') as f:
            lines = f.readlines()
            if lines:
                last_line = lines[-1].strip()
            else:
                last_line = 'Failed'

        if re.search('completed OK', last_line):
            logging.warning("prepare 已经执行成功，无需再次执行")
            execute_code = 0
        else:
            execute_code = 1
    else:
        execute_code = 1

    if execute_code == 1:
        logging.info(f"开始执行 prepare 脚本：{prepare_cmd}")
        exit_code = os.system(prepare_cmd)

        with open(prepare_log_file, 'r') as f:
            lines =  f.readlines()
            if lines:
                last_line = lines[-1].strip()
            else:
                last_line = 'Failed'

        if exit_code > 0 or not re.search('completed OK', last_line):
            raise Exception(f"执行 prepare 脚本错误：{prepare_cmd}")
        logging.info(f"执行 prepare 脚本完成")

@log_decorator
def restore_copyback_db(restore_db_dir_dict, target_backup_dir):
    """恢复数据库"""
    copyback_log_file = os.path.join(restore_db_dir_dict['restore_db_dir'], 'backup_copy_back.log')
    # 改为move-back
    copy_back_cmd = f"xtrabackup --defaults-file={os.path.join(restore_db_dir_dict['restore_db_conf_dir'], f'my.cnf')} --move-back --target-dir={target_backup_dir} 2> {copyback_log_file}"
    logging.info(f"开始执行 copyback 脚本：{copy_back_cmd}")
    exit_code = os.system(copy_back_cmd)

    with open(copyback_log_file, 'r') as f:
        lines = f.readlines()
        if lines:
            last_line = lines[-1].strip()
        else:
            last_line = 'Failed'

    if exit_code > 0 or not re.search('completed OK', last_line):
        raise Exception(f"执行 copyback 脚本错误：{copy_back_cmd}")
    logging.info(f"执行 copyback 脚本完成")

    logging.info(f"更改目录权限组")
    os.system(f"chown -R {mysql_restore_osuser}. {restore_db_dir_dict['restore_db_dir']}")

    end_size = get_folder_size(restore_db_dir_dict['restore_db_dir'])
    restore_info['copyback_size'] = end_size
    restore_info['restore_dir'] = restore_db_dir_dict['restore_db_dir'].replace(f'{restore_base_dir}/', '')

@log_decorator
def start_restore_mysql(restore_db_dir):
    "启动 restore mysql 并修改用户密码"

    restore_process_info_socket, restore_process_info_cnf = get_mysql_socket_by_port(mysql_restore_port)
    if not restore_process_info_socket == None:
        raise Exception(f"Mysql 端口 {mysql_restore_port} 存在")

    start_cmd = f"{mysql_base_dir}/bin/mysqld_safe --defaults-file={os.path.join(restore_db_dir,'conf')}/my.cnf --user={mysql_restore_osuser} &2>&1 > /dev/null"

    if not os.path.exists(f"{os.path.join(restore_db_dir,'log')}/alert.log"):
        touch_alert_log_cmd =f"touch {os.path.join(restore_db_dir,'log')}/alert.log && chown -R {mysql_restore_osuser}. {os.path.join(restore_db_dir,'log')}"

        exec_code = os.system(touch_alert_log_cmd)
        if exec_code > 0:
            raise Exception(f"创建 restore mysql alert.log 失败")

    exec_code = os.system(start_cmd)
    if exec_code > 0:
        raise Exception(f"启动 restore mysql 失败")

    time.sleep(10)

    retry_count = 1
    # 创建一个MySQL连接
    while True:
        try:
            connection = pymysql.connect(
                unix_socket=f"{os.path.join(restore_db_dir,'run')}/mysql{mysql_restore_port}.sock",
                user='root',
                password=''
            )
            logging.warning(f"重试数据库连接第 {retry_count} 次成功")
            break
        except:
            logging.warning(f"重试数据库连接第 {retry_count} 次失败")

        if retry_count <= 5:
            retry_count = retry_count + 1
            time.sleep(10)
            continue
        else:
            raise Exception(f"数据库连接失败")

    # 创建一个游标对象
    cursor = connection.cursor()

    # 执行SQL查询
    cursor.execute("""SELECT CONCAT('show grants for ',USER,'@','''',HOST,''';') FROM mysql.user WHERE USER NOT IN ('mysql.infoschema','mysql.session','mysql.sys','root') and host not in ('localhost');""")

    # 获取查询结果
    result = cursor.fetchall()

    # 打印查询结果
    grant_sql = []
    for row in result:
        cursor.execute(row[0])
        sql_info = cursor.fetchall()
        for i in sql_info:
            grant_sql.append(i[0].split('@')[0] + '@`172.30.%`')

    # 执行SQL查询
    cursor.execute("""SELECT CONCAT('drop user ',USER,'@','''',HOST,''';') FROM mysql.user WHERE USER NOT IN ('mysql.infoschema','mysql.session','mysql.sys','root') and host not in ('localhost');""")

    # 获取查询结果
    result = cursor.fetchall()

    # 打印查询结果
    drop_sql = []
    for row in result:
        drop_sql.append(row[0])

    # 执行SQL查询
    cursor.execute("""SELECT DISTINCT CONCAT('create user ',USER,'@','''','172.30.%','''',' identified by ''','dzjpwd_',USER,'_',SUBSTR(HEX(MD5(USER)),1,2),''';') FROM mysql.user WHERE USER NOT IN ('mysql.infoschema','mysql.session','mysql.sys','root') and host not in ('localhost');""")

    # 获取查询结果
    result = cursor.fetchall()

    # 打印查询结果
    create_sql = []
    for row in result:
        create_sql.append(row[0])


    for sql in drop_sql:
        cursor.execute(sql)

    for sql in create_sql:
        cursor.execute(sql)

    for sql in grant_sql:
        cursor.execute(sql)

    cursor.execute('flush privileges;')
    # 关闭游标和连接
    cursor.close()
    connection.close()


@log_decorator
def init_mysql(db_dir,port=mysql_restore_port,init_sql_dir_info=init_sql_dir):
    "初始化 Mysql 数据"
    # 创建 restore mysql 用户
    time.sleep(5)


    retry_count = 1
    # 创建一个MySQL连接
    while True:
        try:
            connection = pymysql.connect(
                unix_socket=f"{os.path.join(db_dir, 'run')}/mysql{port}.sock",
                user='root',
                password=''
            )
            logging.warning(f"重试数据库连接第 {retry_count} 次成功")
            break
        except:
            logging.warning(f"重试数据库连接第 {retry_count} 次失败")

        if retry_count <= 5:
            retry_count = retry_count + 1
            time.sleep(10)
            continue
        else:
            raise Exception(f"数据库连接失败")

    # 创建一个游标对象
    cursor = connection.cursor()

    sql_files = []
    for root, dirs, files in os.walk(init_sql_dir_info):
        for file in files:
            if file.endswith(".sql"):
                sql_files.append(os.path.join(root, file))

    for sql_file in sql_files:
        try:
            error_count = 0
            logging.info(f"开始执行SQL文件 {sql_file}")
            with open(sql_file,'r') as f:
                sql_content=f.read()
            if sql_content:
                sql_info = [i for i in sql_content.split(';')]
                for line in sql_info:
                    line = line.strip()
                    if line:
                        try:
                            if re.search('into\s+outfile',line,flags=re.I):
                                a = re.match('(.*)into\s+outfile(.*)fields(.*)', line, re.I)
                                file_name = os.path.join(outfile_dir,current_min + '_' + os.path.split(a.group(2).replace('"','').strip())[1])
                                column_file = os.path.join(outfile_dir,current_min + '_column_' + os.path.split(a.group(2).replace('"','').strip())[1])
                                line = a.group(1) + ' into outfile "' + file_name +  '" fields ' + a.group(3)
                                cursor.execute(a.group(1) + ' limit 1')
                                columns = cursor.description
                                with open(column_file,'w') as f:
                                    f.write(','.join([i[0] for i in columns]))

                            cursor.execute(line)
                            cursor.execute('commit')
                        except Exception as e:
                            logging.error(f"执行SQL语句 {line} 失败")
                            logging.error(f'失败原因 {e}')
                            if print_error_line:
                                traceback.print_exc()
                            error_count = error_count + 1

                if error_count > 0:
                    # 消息内容
                    msg = f"Init Sql {sql_file} executed failed \n请查看恢复日志：{log_dir}"
                    for agentid in agent_id:
                        Status = SendMessage(subject, msg, agentid)

            logging.info(f"执行SQL文件 {sql_file} 成功")
        except Exception as e:
            logging.warning(f"执行SQL文件 {sql_file} 失败")
            logging.error(f'失败原因 {e}')
            if print_error_line:
                traceback.print_exc()

    # 关闭游标和连接
    cursor.close()
    connection.close()


import psutil

def get_mysql_socket_by_port(port):
    for proc in psutil.process_iter(['pid', 'name']):
        try:
            conn = proc.connections()
            for c in conn:
                if c.status == 'LISTEN' and c.laddr.port == port:
                    pid = proc.info['pid']
                    proc = psutil.Process(pid)
                    cmdline = proc.cmdline()
                    socket_file = None
                    cnf_file = None
                    for arg in cmdline:
                        match = re.search(r'--socket=(.*)', arg)
                        if match:
                            socket_file = match.group(1)

                        match = re.search(r'--defaults-file=(.*)', arg)
                        if match:
                            cnf_file = match.group(1)
                    logging.info(f"Mysql {port} cnf文件目录：{cnf_file}")
                    logging.info(f"Mysql {port} socket文件目录：{socket_file}")
                    return socket_file,cnf_file
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass

    return None,None

@log_decorator
def switch_restore_mysql(new_port):
    """切换mysql端口"""

    # 根据端口获取进程信息
    if change_port:
        old_process_info_socket,old_process_info_cnf = get_mysql_socket_by_port(change_port)
        if not old_process_info_socket == None:

            head, file = os.path.split(old_process_info_socket)
            db_dir = os.path.split(head)[0]
            init_mysql(db_dir, change_port, old_db_sql_dir)

            shutdown_cmd = f'{mysql_base_dir}/bin/mysql -S {old_process_info_socket} -e "shutdown;"'
            exec_code = os.system(shutdown_cmd)
            if exec_code > 0:
                raise Exception(f"关闭 Mysql 端口 {change_port} 失败，socket文件: {old_process_info_socket}")
            logging.info(f"关闭 Mysql 端口 {change_port} 成功，socket文件: {old_process_info_socket}")
        else:
            logging.warning(f"Mysql 端口 {change_port} 不存在")


    new_process_info_socket,new_process_info_cnf = get_mysql_socket_by_port(new_port)
    if not new_process_info_socket == None:
        sed_cmd = f'sed -i s/{new_port}/{change_port}/g {new_process_info_cnf}'
        exec_code = os.system(sed_cmd)
        if exec_code > 0:
            raise Exception(f"restore mysql {new_process_info_cnf} 替换端口失败")
        logging.info(f"restore mysql {new_process_info_cnf} 替换端口成功")

        shutdown_cmd = f'{mysql_base_dir}/bin/mysql -S {new_process_info_socket} -e "shutdown;"'
        exec_code = os.system(shutdown_cmd)
        if exec_code > 0:
            raise Exception(f"关闭 mysql端口 {new_port} 失败，socket文件: {new_process_info_socket}")
        logging.info(f"关闭 mysql端口 {new_port} 成功，socket文件: {new_process_info_socket}")
        time.sleep(10)

        start_cmd = f"{mysql_base_dir}/bin/mysqld_safe --defaults-file={new_process_info_cnf} --user={mysql_restore_osuser} &2>&1 > /dev/null"
        exec_code = os.system(start_cmd)
        if exec_code > 0:
            raise Exception(f"启动 restore mysql {change_port} 失败")
        logging.info(f"启动 restore mysql {change_port} 成功")
    else:
        raise Exception(f"Mysql 端口 {new_port} 不存在，请检查")


@log_decorator
def delete_backup_dir(delete_date,target_backup_dir):
    """删除备份目录"""
    dir_list = os.listdir(target_backup_dir)
    str = ''
    for i in dir_list:
        dir_date = i.split('_')[0]
        if int(dir_date) < int(delete_date):
            delete_dir = os.path.join(target_backup_dir,i)
            logging.warning(f'开始删除 {delete_dir} .....')
            shutil.rmtree(delete_dir)
            str = str + ',' + delete_dir
    restore_info['delete_dir'] = str

def restore_info_to_csv(restore_info):
    """将恢复信息写入csv文件"""
    column_list=[
            'log_date','log_file','source_backup_host','state',
            'run_type_num','run_type','loop_type','excute_day','restore_date','mysql_dir','already_switch',
            'restore_conf_file', 'source_file_dir', 'target_file_dir', 'restore_dir',
            'start_size', 'decompress_size', 'copyback_size',
            'create_restore_dir','create_conf','sync_backup_file','restore_decompress_db','restore_prepare_db','restore_copyback_db','start_restore_mysql','switch_restore_mysql','init_mysql','delete_backup_dir',
            'total_second',
            'delete_dir',
    ]

    df = pd.DataFrame(columns=column_list)
    if os.path.exists(csv_file):
        df.append(restore_info,ignore_index=True).to_csv(csv_file, mode='a', header=False,index=False)
    else:
        df.append(restore_info,ignore_index=True).to_csv(csv_file, mode='a', header=True, index=False)


@log_decorator
def sendmail():
    """发送邮件报告"""
    a = send_mail()
    a.send_mail(mail_info)


def run():
    start = datetime.datetime.now()
    parse_arg()
    set_logger(log_dir)
    restore_cur_date = ''
    if run_type == 1:
        restore_cur_date = get_restore_date()
        if restore_cur_date:
            if loop_type not in [11,12]:
                delete_backup_dir(restore_cur_date,target_backup_dir)
            logging.info(f"当前时间符合恢复策略,开始恢复 {restore_cur_date} 的备份")
            restore_db_dir_dict = create_restore_dir(restore_base_dir,restore_cur_date)
            create_conf(conf_tmp,mysql_restore_port,restore_db_dir_dict['restore_db_dir'],mysql_base_dir)
            backup_dir = sync_backup_file(source_backup_dir,source_backup_user,source_backup_host,source_backup_passwd,target_backup_dir,restore_cur_date)
            restore_decompress_db(backup_dir)
            restore_prepare_db(backup_dir)
            restore_copyback_db(restore_db_dir_dict, backup_dir)

            if auto_start:
                start_restore_mysql(restore_db_dir_dict['restore_db_dir'])

                if auto_switch:
                    switch_restore_mysql(mysql_restore_port)

                if auto_init:
                    if auto_switch:
                        init_mysql(restore_db_dir_dict['restore_db_dir'], change_port)
                    else:
                        init_mysql(restore_db_dir_dict['restore_db_dir'], mysql_restore_port)

        else:
            logging.warning("当前时间不符合恢复策略")
    elif run_type == 2:
        logging.info(f"手动清理无用备份：备份日期小于 {restore_date} 则全部被清除")
        delete_backup_dir(restore_date, target_backup_dir)
    elif run_type == 3:
        logging.info(f"手动启动已恢复备份")
        if mysql_dir:
            start_restore_mysql(mysql_dir)
        else:
            logging.error(f"请检查 {mysql_dir} 目录是否存在")
    elif run_type == 4:
        logging.info(f"手动切换环境")
        switch_restore_mysql(mysql_restore_port)
    elif run_type == 5:
        logging.info(f"手动初始化数据库数据")
        if mysql_dir:
            if already_switch:
                init_mysql(mysql_dir,change_port)
            else:
                init_mysql(mysql_dir,mysql_restore_port)
        else:
            logging.error(f"请检查 {mysql_dir} 目录是否存在")


    end = datetime.datetime.now()
    exec_time_second = (end - start).total_seconds()
    func_exec_time_dic['total_second'] = exec_time_second

    logging.info(f"脚本执行完毕，耗时 : {change_second(exec_time_second)}")

    restore_info['log_date'] = datetime.datetime.strptime(current_min,'%Y-%m-%d_%H%M').strftime('%Y%m%d %H:%M')



    logging.info("=" * 120)
    logging.info("时间汇总：")
    for k,v in func_exec_time_dic.items():
        logging.info(f"{k.ljust(30)} : {change_second(v)}")
        restore_info[k] = change_second(v)


    restore_info['state'] = f'Ending'
    #sendmail()
    if run_type==1:
        if restore_cur_date:
            restore_info_to_csv(restore_info)
            sendmail()
    else:
        restore_info_to_csv(restore_info)



@log_decorator
def create_conf(conf_tmp,dbport,restore_dir,server_dir):
    """生成 Mysql 配置文件"""
    conf_file = os.path.join(restore_dir,f'conf/my.cnf')
    restore_info['restore_conf_file'] = conf_file
    with open(conf_file,'w') as f:
        f.write(conf_tmp.replace('basedir=/usr/local/data/mysql',f'basedir={server_dir}')
                .replace('lc_messages_dir=/usr/local/data/mysql/share',f'lc_messages_dir={server_dir}/share')
                .replace('/usr/local/data/mysql_data/db3106',restore_dir)
                .replace('3106',str(dbport)))
        server_id = random.randint(10000, 99999)
        f.write(f'server_id = {server_id}\n')

    logging.info(f"生成Mysql配置文件成功：{conf_file}")


if __name__=='__main__':
    run()

