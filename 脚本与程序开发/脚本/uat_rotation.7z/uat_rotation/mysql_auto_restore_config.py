import logging,os

print_error_line = 0
auto_start=1
auto_init=1
auto_switch=1
auto_send_msg = 1
auto_send_reboot_msg = 1
timedelta_day=1
######################################  定义 邮件 配置参数 ##########################################

# 邮件告警配置 1 excel + 邮件显示 2 邮件显示 3 excel
mail_info = [
    {
        'mail_name':'UAT数据库恢复_日期',
        'mail_flag':1,
        'mail_user':'qianxzh@dazhuanjia.com,shenxiang@dazhuanjia.com',
        'mail_cc':'chenyh@dazhuanjia.com',
        'column_flag':0
    },
    {
        'mail_name': 'DBA_UAT数据库恢复_日期',
        'mail_flag': 1,
        'mail_user': 'qianxzh@dazhuanjia.com',
        'mail_cc': 'dba@dazhuanjia.com,caohang@dazhuanjia.com,shenxiang@dazhuanjia.com',
        'column_flag':1
    },
]


rows_limit=10
other_column_need=['log_date','run_type','state']
dba_column_need=[
            'log_date','state',
            'source_backup_host', 'source_file_dir', 'restore_dir',
            'start_size', 'decompress_size', 'copyback_size',
            'sync_backup_file','restore_decompress_db','restore_prepare_db','restore_copyback_db',
            'total_second',
            'delete_dir',
]

######################################  定义 源备份文件 配置参数 ##########################################
source_backup_dir='/usr/local/data/mysql_backup'
source_backup_host='172.30.70.45'
source_backup_user='root'
source_backup_passwd='dzj123,./'


######################################  定义 恢复备份文件 配置参数 ##########################################
# mysql 执行文件目录
mysql_base_dir='/usr/local/data/mysql'

# mysql 备份文件保存目录
target_backup_dir='/usr/local/data/mysql_backup'

# mysql 恢复文件保存目录
restore_base_dir='/usr/local/data/mysql_data'

######################################  定义 其他 配置参数 ##########################################
# 备份恢复脚本 log 日志目录
log_dir='/usr/local/data/script/auto_restore_log'
csv_file = os.path.join(log_dir,f'mysql_auto_restore_total.csv')
# 初始化脚本 目录
init_sql_dir='/usr/local/data/script/init_sql'
old_db_sql_dir='/usr/local/data/script/old_db_sql_dir'
outfile_dir='/usr/local/data/mysql_outfile'

######################################  定义 常用变量 配置参数 ##########################################
# 常用变量
mysql_restore_osuser = 'mysql'
mysql_restore_port = 3206
change_port = 3406
log_level = logging.INFO
paraller = 4

######################################  定义 告警 配置参数 ##########################################

# 企业微信机器人
webhook_url = 'https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=f1ae1bb0-c7c6-4a58-93c8-1d33d1ffbe3c'

# Corpid是企业号的标识
Corpid = "ww980c7371d32a988e"

# Secret是管理组凭证密钥
Secret = "I2z7ecbDz7vmuhZefxMpHFnQ_ianZrZoqbxEeXlPje8"

# agentid
agent_id = (1000007,)

# token_file文件放置路径
token_file = r'/tmp/qywechat_token.txt'

######################################  定义 配置文件 配置参数 ##########################################

conf_tmp=f"""
[mysqld_safe]
pid-file=/usr/local/data/mysql_data/db3106/run/mysqld3106.pid

[mysql]
port=3106
prompt=\\u@\\d \\r:\\m:\\s>
default-character-set=utf8mb4
no-auto-rehash

[client]
port=3106
socket=/usr/local/data/mysql_data/db3106/run/mysql3106.sock
default_character_set=utf8mb4

[mysqld]
#####dir#####
secure_file_priv={outfile_dir}
basedir=/usr/local/data/mysql
lc_messages_dir=/usr/local/data/mysql/share
datadir=/usr/local/data/mysql_data/db3106/data/
tmpdir=/tmp
socket=/usr/local/data/mysql_data/db3106/run/mysql3106.sock

#####log#####
log-error=/usr/local/data/mysql_data/db3106/log/alert.log
slow_query_log_file=/usr/local/data/mysql_data/db3106/log/slow.log
general_log_file=/usr/local/data/mysql_data/db3106/log/general.log
slow_query_log=1
long_query_time=1
log_slow_admin_statements=1
general_log=0
log_error_verbosity=2

#####binlog#####
log-bin=/usr/local/data/mysql_data/db3106/log/mysql-bin
binlog_cache_size=64M
max_binlog_cache_size=2G
max_binlog_size=512M
binlog-format=ROW
sync_binlog=100
log-slave-updates=1
expire_logs_days=7

#####innodb#####
#server
default_authentication_plugin=mysql_native_password
default-storage-engine=INNODB
character-set-server=utf8mb4
transaction-isolation=READ-COMMITTED
innodb_rollback_on_timeout=0
lower_case_table_names=1
local-infile=1
open_files_limit=65535
safe-user-create
explicit_defaults_for_timestamp=true

innodb_open_files=60000
innodb_file_per_table=1
innodb_flush_method=O_DIRECT
innodb_change_buffering=inserts
innodb_adaptive_flushing=1
innodb_old_blocks_time=1000
innodb_stats_on_metadata=0
innodb_use_native_aio=0
innodb_strict_mode=1

innodb_data_home_dir=/usr/local/data/mysql_data/db3106/data
innodb_data_file_path=ibdata1:16M;ibdata2:16M:autoextend


#performance
performance_schema=1

#redo
innodb_log_group_home_dir=/usr/local/data/mysql_data/db3106/data
innodb_log_files_in_group=3
innodb_log_file_size=512M
innodb_log_buffer_size=20M
innodb_flush_log_at_trx_commit=1

#undo
innodb_undo_directory=/usr/local/data/mysql_data/db3106/data
innodb_undo_tablespaces=4
innodb_max_undo_log_size=800M
innodb_undo_log_truncate=1

#lock
innodb_lock_wait_timeout=5
innodb_print_all_deadlocks=1
skip-external-locking


#buffer
innodb_buffer_pool_size=40G
innodb_buffer_pool_instances=4
innodb_buffer_pool_dump_pct=75
innodb_max_dirty_pages_pct=60
innodb_read_ahead_threshold=64

table_definition_cache=65536
thread_stack=128M
thread_cache_size=256M
read_rnd_buffer_size=1G
sort_buffer_size=1G
join_buffer_size=1G
read_buffer_size=1G
max_heap_table_size=1G
key_buffer_size=1G
tmp_table_size=1G

#thread
innodb_io_capacity=4000
innodb_thread_concurrency=16
innodb_read_io_threads=16
innodb_write_io_threads=16
innodb_purge_threads=1

max_connections=4500
max_user_connections=4000
max_connect_errors=10000
max_allowed_packet=128M
connect_timeout=8
net_read_timeout=30
net_write_timeout=60

#####myisam#####
myisam_sort_buffer_size=64M
concurrent_insert=2
delayed_insert_timeout=300

#####replication#####
master-info-file=/usr/local/data/mysql_data/db3106/log/master.info
relay-log=/usr/local/data/mysql_data/db3106/log/relaylog
relay_log_info_file=/usr/local/data/mysql_data/db3106/log/relay-log.info
relay-log-index=/usr/local/data/mysql_data/db3106/log/mysqld-relay-bin.index
slave_load_tmpdir=/usr/local/data/mysql_data/db3106/tmp
slave_type_conversions="ALL_NON_LOSSY"
slave_net_timeout=4
skip-slave-start
sync_master_info=1000
sync_relay_log_info=1000
relay_log_recovery=1
relay_log_purge=1

#####gtid#####
gtid_mode=on
enforce_gtid_consistency=on

#####other#####
port=3106
back_log=1024
skip-name-resolve
skip-ssl
#read_only=1
"""

######################################  定义参数 ##########################################
