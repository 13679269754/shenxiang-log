#! /usr/bin/env python
#-*- coding:utf-8 -*-
import os
import sys
import pymysql
import pandas as pd
from datetime import datetime,timedelta

##接收参数
if len(sys.argv) <= 2:
	print("清提供相关参数")
	sys.exit(1)

first_argument = sys.argv[1]
second_argument = int(sys.argv[2])

db = pymysql.connect(host = '172.30.70.41',
                             user = 'dzjcaohang',
                             password = 'dzjcaohang_pwd',
                             port = 3106,
                             database = 'table_backup')
cursor = db.cursor()

def data_count(v_sample_updatetime):
	select_data_count = ("	select count(1) \
				from  `table_backup`.temp_sample_code_list \
				where sample_updatedate=date('%s');"%v_sample_updatetime)
	cursor.execute(select_data_count)
	results = cursor.fetchall()
	for row in results:
		results_id = row[0]
	return results_id

def data_sample_json(v_sample_code):
	##查询并处理数据(json)格式
	select_json_data = ("	SELECT    ifnull(CONCAT('{',GROUP_CONCAT(SUBSTRING(REVERSE(SUBSTRING(REVERSE(JSON_OBJECT(question_code,answer)),2,LENGTH(REVERSE(JSON_OBJECT(question_code,answer))))),2,LENGTH(JSON_OBJECT(question_code,answer)))),'}'),'{}') \
				FROM research.question_answer_instance \
				WHERE 	IFNULL(answer,'') <> '' \
					AND sample_code ='%s';"%v_sample_code)
	try:
		cursor.execute(select_json_data)
		results = cursor.fetchall()
		for row in results:
			v_json_data = row[0]
#			print (v_json_data)
	except:
		print ("错误，没有查找到数据3")
	insert_sample_content(v_sample_code,v_json_data)


def data_select_id(v_sample_updatetime):
	##获取时间范围内的最小值及最大值
	select_data_range = ("	select ifnull(min(id),0),ifnull(max(id),0) \
				from `table_backup`.temp_sample_code_list \
				where sample_updatedate='%s'"%v_sample_updatetime)
	try:
		cursor.execute(select_data_range)
		results = cursor.fetchall()
		for row in results:
			v_min_id = row[0]
			v_max_id = row[1]
	except:
		print ("错误，没有查找到数据1")
	return v_min_id,v_max_id

def select_sample_code(v_sample_updatetime):
	v_id  = data_select_id(v_sample_updatetime)
	v_min_id = v_id[0]
	v_max_id = v_id[1]
	##获取sample_code
	if v_min_id == 0:
		print (v_sample_updatetime,"当日无数据")
	else:
		while v_min_id <= v_max_id:
			select_sample_code = ("	select sample_code \
						from `table_backup`.temp_sample_code_list \
						where id = %s;"%v_min_id)
			try:
				cursor.execute(select_sample_code)
				results = cursor.fetchall()
				for row in results:
					v_sample_code = row[0]
					data_sample_json(v_sample_code)
				
			except:
				print ("错误，没有查找到数据2")
			v_min_id = v_min_id + 1

def insert_sample_content(v_sample_code,v_json_data):
	##插入新表
	if v_json_data == "{}":
		print (v_sample_code,"没有问题内容")
	else:
		insert_sample_data = ("	replace INTO `research`.`sample_context`(id,`code`,sample_code,context,create_time,modify_time,is_deleted) \
					SELECT 	REPLACE(`code`,'SAP',''),REPLACE(`code`,'SAP','SCT'),`code`,'%s',create_time,modify_time,0 \
					FROM 	research.sample \
					WHERE	`code` = '%s';"%(v_json_data,v_sample_code))
		try:
			cursor.execute(insert_sample_data)
			db.commit()
		except:
			db.rollback()
	update_log_status = ("	update `table_backup`.temp_sample_code_list set move_status = move_status + 1 	where sample_code = '%s';"%v_sample_code)
	try:
		cursor.execute(update_log_status)
		db.commit()
	except:
		db.rollback()

	
	
#根据入参进行日期循环
def date_loop(first_argument,second_argument):
	i = 0
	while i <= second_argument:
		v_date = pd.to_datetime(first_argument) + timedelta(days = i)
		i = i + 1
		v_data_count = int(data_count(v_date))
		if v_data_count == 0:
			print (v_date,'当日没有数据')
		else:
			select_sample_code(v_date)
#	cursor.close()
#	db.close()
date_loop(first_argument,second_argument)
cursor.close()
db.close()
