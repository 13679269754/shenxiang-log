#!/usr/bin/env python
# -*- coding:utf-8 -*-

"""
mysql_report_job/

date : 2024/4/22
comment : 提示信息
"""
from config import html_path
from mail import report_mail
from mysql_operator import reporterOperator,init_db
import argparse

def parser_cmd_args():
    """
    实现命令行参数的处理
    """
    parser = argparse.ArgumentParser(
        __name__, formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    parser.epilog = """该脚本用户获得数据库基本运行状态"""


    parser.add_argument(
        "-i","--init_db",
        action="store_true",
        help=f"当次参数存在时表示初始化，默认进行初始化"
    )

    parser.add_argument(
        "-iu","--init_user",
        type=str,
        default='',
        help=f"初始化用户"
    )

    parser.add_argument(
        "-ip","--init_password",
        type=str,
        default='',
        help=f"初始化密码"
    )

    parser.add_argument(
        "-ih","--init_host",
        type=str,
        default='',
        help=f"初始化host"
    )

    parser.add_argument(
        "-iP","--init_port",
        type=str,
        default='',
        help=f"初始化端口"
    )
    parser.add_argument(
        "-sort","--sort_metric",
        action="store_true",
        help=f"当次参数存在时表示进行指标的重排序，用于控制输出的html页面中的指标显示顺序,也可以手动更新数据库中的order_id值,默认不重新排序"
    )

    args = parser.parse_args()

    return args

if __name__ == "__main__":
    args=parser_cmd_args()
    try :
        # 初始化数据库
        if  args.init_db and args.init_user != '' and args.init_password != '' and args.init_host != '' and args.init_port != '':
            db_init = {'host': str(args.init_host), 'port': str(args.init_port), 'user': str(args.init_user), 'password': str(args.init_password)}
            init_db(db_init)
    except Exception as e:
        print(e)

    # 获取操作对象
    config_db = reporterOperator()
    # 指标重排序
    if args.sort_metric:
        reporterOperator().sort_metric()

    args = parser_cmd_args()
    # 获得sql
    config_db.get_all_query()
    # 获取metric
    config_db.get_all_metric()
    # 写入metric
    config_db.insert_all_metric()
    # 计算指标
    config_db.os_calculate_fun_handle()
    # 生成html
    config_db.metric_result_html_format()

    # 发送邮件
    report_mail(config_db,html_path)


