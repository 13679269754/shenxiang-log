#!/usr/bin/env python
# -*- coding:utf-8 -*-

"""
mysql_report_job/

author: shen
date : 2024/5/24
comment : 提示信息
"""
import os
import smtplib
import time

from config import recipientAddrs, ip_filter
from log_format import log_decorator, logger
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders


@log_decorator
def report_mail(operator_obj, attachment_path):
    today = time.strftime("%Y%m%d", time.localtime())  # Get today's date in the format YYYYMMDD

    attachment_file_names = []
    for file_name in os.listdir(attachment_path):
        file_path = os.path.join(attachment_path, file_name)
        if os.path.isfile(file_path) and file_name.startswith(f"{ip_filter}") and file_name.endswith(".html"):
            file_date = file_name.split("_")[2]  # Extract the date part from the file name
            if file_date == today:
                attachment_file_names.append(file_path)

    attachment_file_names.sort()

    # Construct the email content with the filtered attachment file names
    table_rows = ""
    for file_path in attachment_file_names:
        file_name = os.path.basename(file_path)
        table_rows += f"<tr><td>{file_name}</td></tr>"

    html_msg = """
    <html>
    <head>
        <style type="text/css">
            table  {{ font: 11px Consolas; color: Black; background: #FFFFCC; padding: 1px; margin: 0px; cellspacing: 0px; border-collapse: collapse; }}
            th  {{ font: bold 11px Consolas; color: White; background: #0066cc; padding: 5px; cellspacing: 0px; border-collapse: collapse; white-space: nowrap; }}
            td {{ font-family: Consolas; word-wrap: break-word; white-space: pre-wrap; }}
            tr:nth-child(odd) {{ background: White; }}
            tr:hover {{ background-color: yellow; }}
        </style>
    </head>
    <body>
        <h2>Attachment File List:</h2>
        <table border="1">
            <tr>
                <th>File Name</th>
            </tr>
            {table_rows}
        </table>
    </body>
    </html>
    """.format(table_rows=table_rows)
    msg = MIMEMultipart()
    msg['From'] = 'DBA@dazhuanjia.com'
    msg['To'] = recipientAddrs
    msg['Subject'] = today + '数据库状态报告'

    for file_path in attachment_file_names:
        attachment = open(file_path, 'rb')
        part = MIMEBase('application', 'octet-stream')
        part.set_payload(attachment.read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', f'attachment; filename="{os.path.basename(file_path)}"')
        msg.attach(part)

    msg.attach(MIMEText(html_msg, "html", "utf-8"))

    send = smtplib.SMTP("localhost")
    send.sendmail("localhost", recipientAddrs.split(','), msg.as_string())

    logger.info('------------- 发送备份报告成功 -------------')

    return True